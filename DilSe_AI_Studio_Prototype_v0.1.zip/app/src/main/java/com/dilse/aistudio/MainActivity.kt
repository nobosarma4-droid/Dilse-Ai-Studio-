package com.dilse.aistudio

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(18, 15, 35))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }
        root.addView(label("DilSe AI Studio", 28f))
        root.addView(label("Create stories with your imagination", 14f, Color.LTGRAY))
        val space = Space(this)
        root.addView(space, LinearLayout.LayoutParams(1, 22))
        root.addView(label("Choose video type", 16f))
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Text to Video", "Image to Video"))
        root.addView(type)
        root.addView(label("Voice language", 16f).apply { setPadding(0, 18, 0, 4) })
        val language = Spinner(this)
        language.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Hindi", "Bengali", "English"))
        root.addView(language)
        val prompt = EditText(this).apply {
            hint = "Apni video ki kahani ya prompt likhein..."
            minLines = 5
            gravity = Gravity.TOP
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(42, 36, 62))
        }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        p.topMargin = 20
        p.bottomMargin = 18
        root.addView(prompt, p)
        val button = Button(this).apply { text = "Prepare Video Prompt" }
        root.addView(button)
        val output = label("Your ready-to-use video prompt will appear here.", 14f, Color.LTGRAY)
        output.setPadding(0, 18, 0, 0)
        root.addView(output)
        button.setOnClickListener {
            val idea = prompt.text.toString().trim()
            if (idea.isEmpty()) {
                Toast.makeText(this, "Please write your story prompt first.", Toast.LENGTH_SHORT).show()
            } else {
                output.text = "Video type: ${type.selectedItem}\nVoice: ${language.selectedItem}\n\nPrompt:\n$idea\n\nNote: Video generation service abhi connect nahi hai. This prototype prepares your prompt; it does not render a video yet."
            }
        }
        setContentView(root)
    }
}
