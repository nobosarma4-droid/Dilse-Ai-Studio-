DilSe AI Studio - Prototype v0.1

Is ZIP mein Android Studio project source hai, ready-made APK nahi.
Abhi app mein Text-to-Video / Image-to-Video selection, Hindi/Bengali/English
language selection aur prompt preparation screen hai.

IMPORTANT:
- Is prototype mein abhi actual AI video rendering connected nahi hai.
- Real video generation ke liye ek video-generation server/API chahiye.
- Free unlimited AI video generation ki guarantee nahi di ja sakti.
- APK banane ke liye Android build environment (Android Studio ya cloud build)
  aur signing/build steps ki zaroorat hogi.

Android Studio mein project folder open karke Gradle sync karein, phir
Build > Build APK(s) use karein.
